// Supabase Configuration Template
// 1. Copy this file to 'config.js'
// 2. Add your Supabase keys below
const SUPABASE_URL = 'YOUR_SUPABASE_URL';
const SUPABASE_ANON_KEY = 'YOUR_SUPABASE_ANON_KEY';
